<?php

namespace Incevio\Package\Wallet\Test;

class CartLockTest extends CartTest
{
    use RaceCondition;
}
