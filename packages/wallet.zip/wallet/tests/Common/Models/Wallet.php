<?php

namespace Incevio\Package\Wallet\Test\Common\Models;

class Wallet extends \Incevio\Package\Wallet\Models\Wallet
{
}
