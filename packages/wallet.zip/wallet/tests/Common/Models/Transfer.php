<?php

namespace Incevio\Package\Wallet\Test\Common\Models;

class Transfer extends \Incevio\Package\Wallet\Models\Transfer
{
}
