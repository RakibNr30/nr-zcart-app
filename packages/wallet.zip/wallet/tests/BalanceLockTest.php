<?php

namespace Incevio\Package\Wallet\Test;

class BalanceLockTest extends BalanceTest
{
    use RaceCondition;
}
