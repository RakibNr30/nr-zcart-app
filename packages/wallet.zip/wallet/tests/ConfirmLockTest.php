<?php

namespace Incevio\Package\Wallet\Test;

class ConfirmLockTest extends ConfirmTest
{
    use RaceCondition;
}
