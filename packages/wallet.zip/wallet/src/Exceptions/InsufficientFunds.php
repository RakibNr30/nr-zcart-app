<?php

namespace Incevio\Package\Wallet\Exceptions;

use LogicException;

class InsufficientFunds extends LogicException
{
}
