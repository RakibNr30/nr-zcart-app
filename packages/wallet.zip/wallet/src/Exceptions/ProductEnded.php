<?php

namespace Incevio\Package\Wallet\Exceptions;

use LogicException;

class ProductEnded extends LogicException
{
}
