<?php

namespace Incevio\Package\Wallet\Exceptions;

class BalanceIsEmpty extends InsufficientFunds
{
}
