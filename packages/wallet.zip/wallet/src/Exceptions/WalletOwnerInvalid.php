<?php

namespace Incevio\Package\Wallet\Exceptions;

use InvalidArgumentException;

class WalletOwnerInvalid extends InvalidArgumentException
{
}
