<?php

namespace Incevio\Package\Wallet\Exceptions;

use InvalidArgumentException;

class AmountInvalid extends InvalidArgumentException
{
}
